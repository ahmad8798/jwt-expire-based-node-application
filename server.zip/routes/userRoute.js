const { registerUser, login } = require('../controllers/Authcontroller');

const userRouter = require('express').Router()

userRouter.route('/registration').post(registerUser)
userRouter.route('/login').post(login)

module.exports = userRouter;